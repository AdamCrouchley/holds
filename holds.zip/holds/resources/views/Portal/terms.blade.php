<x-app-layout title="Terms & Conditions">
    <div class="max-w-3xl mx-auto p-6 space-y-4">
        <h1 class="text-xl font-semibold">Terms &amp; Conditions</h1>
        <p class="text-sm text-gray-600">
            Add your terms & conditions text here.
        </p>
    </div>
</x-app-layout>
