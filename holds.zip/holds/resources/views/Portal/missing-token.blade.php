<x-layouts.app :title="'Payment link error'">
  <div class="card">
    <h1 class="text-xl font-semibold mb-2">This link is incomplete</h1>
    <p class="muted">Ask the rental company for a new payment link with a valid token.</p>
  </div>
</x-layouts.app>
