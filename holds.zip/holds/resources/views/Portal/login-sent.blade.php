<x-app-layout>
    <div class="py-12">
        <div class="mx-auto max-w-md rounded border bg-white p-6 text-center">
            <p>We’ve emailed you a sign-in link if the address exists.</p>
        </div>
    </div>
</x-app-layout>
